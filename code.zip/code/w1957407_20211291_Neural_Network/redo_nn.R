library(neuralnet) # NEURAL NETWORK
library(MLmetrics) # ERROR VALUES
library(readxl) # READ DATASET
library(ggplot2) # FOR PLOT
library(dply)

# DEFINING NORMALIZATION AND DENORMALIZAITON
normalize <- function(x) {return((x - min(x)) / (max(x) - min(x)))}
unnormalize <- function(x, min, max) {return( (max - min)*x + min )}

# SMAPE INBUILT FUNCTION DID NOT WORK SO HAD TO SET IT UP
smape <- function(actual_values, predictions) {  
  return (mean(2 * abs(actual_values - predictions) / (abs(actual_values) + abs(predictions))))
}

# READING DATASET
ExchangeUSD <- read_excel("C:/My Files/w1957407_20211291/ExchangeUSD.xlsx")

# ADDING APRROPRIATE COL NAMES
colnames(ExchangeUSD) <- c("Input_1", "Input_2", "Output")

output_col_og_dataset <- ExchangeUSD[3]
head(output_col_og_dataset)

# GETTING LAGGED VALUES FOR FIRST FOUR OF THE THRID COL OF DATASET
lagged_output_1 <- lag(output_col_og_dataset, 1)
lagged_output_2 <- lag(output_col_og_dataset, 2)
lagged_output_3 <- lag(output_col_og_dataset, 3)
lagged_output_4 <- lag(output_col_og_dataset, 4)

# CREATING IO MATRICES WITH VARYING COMBINATIONS OF LAGGED VALUES
IO_matrix_1 <- cbind(lagged_output_1, lagged_output_2, lagged_output_3, lagged_output_4, output_col_og_dataset)
IO_matrix_2 <- cbind(lagged_output_2, lagged_output_1, lagged_output_3, lagged_output_4, output_col_og_dataset)
IO_matrix_3 <- cbind(lagged_output_4, lagged_output_3, lagged_output_2, lagged_output_1, output_col_og_dataset)
IO_matrix_4 <- cbind(lagged_output_3, lagged_output_4, lagged_output_2, lagged_output_1, output_col_og_dataset)

# PRITNING THE FIRST FEW TO INSPECT
head(IO_matrix_1)
head(IO_matrix_2)
head(IO_matrix_3)
head(IO_matrix_4)

# REMOVING NA VALUES OF THE IO MATRICES
IO_matrix_1 <- IO_matrix_1[complete.cases(IO_matrix_1),]
IO_matrix_2 <- IO_matrix_2[complete.cases(IO_matrix_2),]
IO_matrix_3 <- IO_matrix_3[complete.cases(IO_matrix_3),]
IO_matrix_4 <- IO_matrix_4[complete.cases(IO_matrix_4),]

# PRINTING THE FIRST FEW TO INSPECT
head(IO_matrix_1)
head(IO_matrix_2)
head(IO_matrix_3)
head(IO_matrix_4)

# NORMALIZING THE DATA USING MIN MAX
IO_matrix_1_normz <- normalize(IO_matrix_1)
IO_matrix_2_normz <- normalize(IO_matrix_2)
IO_matrix_3_normz <- normalize(IO_matrix_3)
IO_matrix_4_normz <- normalize(IO_matrix_4)

# PRINTING THE FIRST FEW TO INSPECT
head(IO_matrix_1_normz)
head(IO_matrix_2_normz)
head(IO_matrix_3_normz)
head(IO_matrix_4_normz)

str(IO_matrix_4_normz)
IO_matrix_4_normz

# RENAMING COL NAMES
colnames(IO_matrix_1_normz) <- c("lagged1", "lagged2","lagged3","lagged4", "actualOutput")
colnames(IO_matrix_2_normz) <- c("lagged1", "lagged2","lagged3","lagged4", "actualOutput")
colnames(IO_matrix_3_normz) <- c("lagged1", "lagged2","lagged3","lagged4", "actualOutput")
colnames(IO_matrix_4_normz) <- c("lagged1", "lagged2","lagged3","lagged4", "actualOutput")

# INSPECTING JUST ONE TO CHECK WHETHER COLUMN NAME CHANGED 
head(IO_matrix_1_normz)


### DATASPLIT -> TRAINING 400 - REST FOR TESTING & CCONVERT TO DATAFRAMES TO BE USED IN NN
# TRAINING PART
training_set_1 <- as.data.frame(IO_matrix_1_normz[1:400,]) 
training_set_2 <- as.data.frame(IO_matrix_2_normz[1:400,])
training_set_3 <- as.data.frame(IO_matrix_3_normz[1:400,])
training_set_4 <- as.data.frame(IO_matrix_4_normz[1:400,])

# TESTING PART
testing_set_1 <- as.data.frame(IO_matrix_1_normz[401:nrow(IO_matrix_1_normz),])
testing_set_2 <- as.data.frame(IO_matrix_2_normz[401:nrow(IO_matrix_2_normz),])
testing_set_3 <- as.data.frame(IO_matrix_3_normz[401:nrow(IO_matrix_3_normz),])
testing_set_4 <- as.data.frame(IO_matrix_4_normz[401:nrow(IO_matrix_4_normz),])


# PRINT FIRST FEW JUST TO CHECK WHETHER PROPERLY SPLITTED
nrow(training_set_1)
nrow(training_set_2)
nrow(training_set_3)
nrow(training_set_4)
nrow(testing_set_1)
nrow(testing_set_2)
nrow(testing_set_3)
nrow(testing_set_4)


##### CREATING MLP MODELS ####

# FUNCTION TO SET UP MODELS EASILY
train_mlp_model <- function(seed, input, train_data, hidden_layers, activation) {
  set.seed(seed)
  input_formula <- as.formula(paste("actualOutput ~", paste(input, collapse = " + ")))
  model <- neuralnet(input_formula, data = train_data, hidden = hidden_layers, 
                     act.fct = activation, linear.output = TRUE)
  return(model)
}


# FUNCTION TO SET UP MODELS EASILY WWITHOUT FUNCTION
train_mlp_model_no_func <- function(seed, input, train_data, hidden_layers) {
  set.seed(seed)
  input_formula <- as.formula(paste("actualOutput ~", paste(input, collapse = " + ")))
  model <- neuralnet(input_formula, data = train_data, hidden = hidden_layers, linear.output = TRUE)
  return(model)
}


# MODEL1
mlp_model1 <- train_mlp_model_no_func(12, c("lagged1", "lagged2", "lagged3", "lagged4"),
                                  training_set_1, c(5))

# MODEL2
mlp_model2 <- train_mlp_model(14, c("lagged1", "lagged2", "lagged3", "lagged4"), 
                                  training_set_1, c(4, 6), "logistic")

# MODEL3
mlp_model3<- train_mlp_model_no_func(16, c("lagged1", "lagged3", "lagged4", "lagged2"), 
                                  training_set_1, c(6, 8))

# MODEL4
mlp_model4<- train_mlp_model(18, c("lagged1", "lagged3", "lagged2", "lagged4"),
                                 training_set_1, c(4, 6, 8), "logistic")

# MODEL5
mlp_model5<- train_mlp_model(20, c("lagged1", "lagged4", "lagged3", "lagged2"), 
                         training_set_1, c(8, 6), "tanh")

# MODEL6
mlp_model6<- train_mlp_model(22, c("lagged1", "lagged4", "lagged3", "lagged2"), 
                         training_set_1, c(6, 8), "logistic")

# MODEL7
mlp_model7<- train_mlp_model(24, c("lagged2", "lagged1", "lagged3", "lagged4"), 
                         training_set_2, c(4, 8, 4), "logistic")

# MODEL8
mlp_model8<- train_mlp_model(26, c("lagged2", "lagged3", "lagged4", "lagged1"), 
                             training_set_2, c(6, 4), "tanh")

# MODEL9
mlp_model9<- train_mlp_model(28, c("lagged2", "lagged4", "lagged1", "lagged3"), 
                             training_set_2, c(4, 6, 8), "tanh")

# MODEL10
mlp_model10<- train_mlp_model(30, c("lagged4", "lagged3", "lagged2", "lagged1"), 
                             training_set_3, c(6, 6, 9), "tanh")

# MODEL11
mlp_model11<- train_mlp_model(32, c("lagged4", "lagged1", "lagged3", "lagged2"), 
                              training_set_3, c(6, 4, 8), "logistic")

# MODEL12
mlp_model12<- train_mlp_model(34, c("lagged3", "lagged4", "lagged2", "lagged1"), 
                              training_set_4, c(8), "tanh")

# MODEL13
mlp_model13<- train_mlp_model_no_func(36, c("lagged3", "lagged1", "lagged4", "lagged2"), 
                              training_set_4, c(8, 4, 6))

# MODEL14
mlp_model14<- train_mlp_model(38, c("lagged3", "lagged2", "lagged1", "lagged4"), 
                                      training_set_4, c(10, 6, 8), "tanh")


# PLOTTING FOR INPECTION
plot(mlp_model1)
plot(mlp_model2)
plot(mlp_model3)
plot(mlp_model4)
plot(mlp_model5)
plot(mlp_model6)
plot(mlp_model7)
plot(mlp_model8)
plot(mlp_model9)
plot(mlp_model10)
plot(mlp_model11)
plot(mlp_model12)
plot(mlp_model13)
plot(mlp_model14)


#### MAKING PREDICTIONS ####

## DENORMALIZING THE PREDICTED VALUES AND ACTUAL VALUES ##
training_original_data <- output_col_og_dataset[1:400, ]
nrow(training_original_data)

# GETTING THE MIN AND MAX VALUE OF THE OUTPUT COL TO BE PASSED TO THE DENORMALIZING FUNCTION
min_output <- min(training_original_data$Output)
max_output <- max(training_original_data$Output)
paste("min output: " ,min_output)
paste("maz output: " ,max_output)

# CREATED THIS AS THE SAME CODE WILL BE USED TWICE IN THE LATTER PART OF THE CODE 
calc_error_values_helper <- function(predicted, actual) {
  ### CALCULATING ERROR VALUES ####
  # CALC RMSE
  rmse <- RMSE(predicted, actual)
  
  # CALC MAE
  mae <- MAE(predicted, actual)
  
  # CALC MAPE
  mape <- MAPE(predicted, actual)
  
  # CALC SMAPE
  smape <- smape(predicted, actual)
  
  # RETURN LIST OF ALL THE ERROR STATS
  return(list(RMSE = rmse, MAE = mae, MAPE = mape, SMAPE = smape))
}


calc_error_stats <- function(model, testing_set) {
  # GENERATING THE PREDICTIONS USING THE MODEL AND THE TEST DATASET
  predictions <- predict(model, testing_set)
  
  # EXTRACTING PREDICTED VALUES
  predicted_values <- as.vector(predictions)
  actual_values <- testing_set$actualOutput
  
  # DDENORMALIZING THE PREDICTED VALUES
  predicted_values_denorm <- unnormalize(predicted_values, min_output, max_output)
  
  # DENORMALIZING THE ACTUAL VALUES
  actual_values_denorm <- unnormalize(actual_values, min_output, max_output)
  
  return (calc_error_values_helper(predicted_values_denorm, actual_values_denorm))
}


error_stats <- list()

is.na(testing_set_1)

# PASSING IN THE MODEL AND ITS RELEVANT TESTING SET
error_stats[[1]] <- calc_error_stats(mlp_model1, testing_set_1)
error_stats[[2]] <- calc_error_stats(mlp_model2, testing_set_1)
error_stats[[3]] <- calc_error_stats(mlp_model3, testing_set_1)
error_stats[[4]] <- calc_error_stats(mlp_model4, testing_set_1)
error_stats[[5]] <- calc_error_stats(mlp_model5, testing_set_1)
error_stats[[6]] <- calc_error_stats(mlp_model6, testing_set_1)
error_stats[[7]] <- calc_error_stats(mlp_model7, testing_set_2)
error_stats[[8]] <- calc_error_stats(mlp_model8, testing_set_2)
error_stats[[9]] <- calc_error_stats(mlp_model9, testing_set_2)
error_stats[[10]] <- calc_error_stats(mlp_model10, testing_set_3)
error_stats[[11]] <- calc_error_stats(mlp_model11, testing_set_3)
error_stats[[12]] <- calc_error_stats(mlp_model12, testing_set_4)
error_stats[[13]] <- calc_error_stats(mlp_model13, testing_set_4)
error_stats[[14]] <- calc_error_stats(mlp_model14, testing_set_4)

# DISPLAYIN IT AS A DATA FRAME FOR BETTER COMPARISON
error_stats_df <- data.frame(MLP_MODEL=paste("model -", 1:14), 
                                RMSE = sapply(error_stats, function(x) x$RMSE),
                                MAE = sapply(error_stats, function(x) x$MAE),
                                MAPE = sapply(error_stats, function(x) x$MAPE),
                                SMAPE = sapply(error_stats, function(x) x$SMAPE))


# PRINTING THE DATA FRAME FOR A TABLE FORMAT - EASY TO DO COMPARISON
error_stats_df

# GENERATING THE PREDICTIONS USING THE MODEL AND THE TEST DATASET
predictions <- predict(mlp_model11, testing_set_3)

# EXTRACTING PREDICTED VALUES
predicted_values <- as.vector(predictions)
actual_values <- testing_set_2$actualOutput
nrow(testing_set_2)

# DDENORMALIZING THE PREDICTED VALUES
predicted_values_denorm <- unnormalize(predicted_values, min_output, max_output)

# DENORMALIZING THE ACTUAL VALUES
actual_values_denorm <- unnormalize(actual_values, min_output, max_output)


# PRIINTING TO COMPARE
predicted_values_denorm
actual_values_denorm
nrow(as.data.frame(predicted_values_denorm))
nrow(as.data.frame(actual_values_denorm))
 

# PLOT USING G PLOT FOR PREDICTION OUTPUT VS DESIRED OUTPUT
plot_data <- data.frame(Actual = actual_values_denorm, Predicted = predicted_values_denorm)
ggplot(plot_data, aes(x = Actual, y = Predicted)) +
  geom_point() +
  geom_abline(intercept = 0, slope = 1, color = "red") +
  labs(x = "ACTUAL OUTPUT", y = "PREDICTED OUTPUT", title = "ACTUAL VALUES (RED) VS PREDICTED VALUES(BLACK)")


# DATAFRAME CREATION FOR THE TIME SERIES PLOT
time_series_data <- data.frame(
  Index = 1:nrow(testing_set_2),
  Actual = actual_values_denorm,
  Predicted = predicted_values_denorm
)

# TIME SERIES OF BOTH IN ONE PLOT
ggplot(time_series_data, aes(x = Index)) +
  geom_line(aes(y = Actual, color = "ACTUAL OUTPUT")) +
  geom_line(aes(y = Predicted, color = "PREDICTED OUTPUT")) +
  labs(x = "TIME", y = "EXCHANGE RATE", title = "ACTUAL VALUES(BLUE) VS PREDICTED VALUES(RED)") +
  scale_color_manual(values = c("ACTUAL OUTPUT" = "blue", "PREDICTED OUTPUT" = "red")) +
  theme_minimal()


# GETTING THE ERROR VALUES INDIVIDUALLY AGAIN AS REQUIRED
calc_error_values_helper(predicted_values_denorm, actual_values_denorm)
