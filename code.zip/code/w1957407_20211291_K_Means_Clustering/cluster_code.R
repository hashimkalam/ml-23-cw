library(ggplot2)
library(factoextra)
library(NbClust)
library(cluster)

# READING DATASET
library(readxl)
Whitewine_v6 <- read_excel("C:/My Files/w1957407_20211291/Whitewine_v6.xlsx")

# CHECKING STRUCURE OF DATASET
str(Whitewine_v6)

# REMOVING IF ANY NULL VALUES PRESENT
df <- na.omit(Whitewine_v6)

# CONVERTING DATASET TO DATAFRAME
dfNormZ <- as.data.frame((Whitewine_v6[1:11]))
head(dfNormZ)

### USING TUKEYS METHOD TO IDENTIFY OUTLIERS ###
# FUNCTION TO DETECT OUTLIERS
detect_outliers_tukey <- function(x) {
  qnt <- quantile(x, probs=c(0.25, 0.75), na.rm = TRUE)
  iqr <- IQR(x, na.rm = TRUE)
  fence_low <- qnt[1] - 1.5 * iqr
  fence_high <- qnt[2] + 1.5 * iqr
  outliers <- which(x < fence_low | x > fence_high)
  return(outliers)
}

# APPLYING THE ABOVE FUNTCION TO EACH VARIABLE/FEATURE IN THE DATASET
outliers_tukey <- apply(dfNormZ, 2, detect_outliers_tukey)

# COMBINE OUTLEIRS DETECTED FOR ALL FEATURES
all_outliers <- unique(unlist(outliers_tukey))

# REMOVING THE DETECTED OUTLIERS FROM THE DATASET
dfNormZ_no_outliers <- dfNormZ[-all_outliers, ]

# SCALING THE CLEANED DATASET
dfNormZ_no_outliers <- scale(dfNormZ_no_outliers)

# CONVERTING IT TO A DATA FRAME NOW
dfNormZ_no_outliers <- as.data.frame(dfNormZ_no_outliers)

# BOXPLOTTNG BOTH THE DATA FRAME WITH OUTLIERS AND WITHOUT OUTLIERS
boxplot(dfNormZ, main = "With Outliers")
boxplot(dfNormZ_no_outliers, main = "Without Outliers")

# VISUALIZING USING GPLOT BOTH THE DATA FRAME WITH OUTLIERS AND WITHOUT OUTLIERS
ggplot(data = dfNormZ, aes(x = dfNormZ[,9], y = dfNormZ[,9])) +
  geom_point() +
  labs(title = "With Outliers", x = "Variable 1", y = "Variable 2")
ggplot(data = dfNormZ_no_outliers, aes(x = dfNormZ_no_outliers[,9], y = dfNormZ_no_outliers[,9])) +
  geom_point() +
  labs(title = "Without Outliers", x = "Variable 1", y = "Variable 2")


## PERFORM NB CLUST ## 
# EUCLIDEAN
set.seed(10)
nb <- NbClust(dfNormZ_no_outliers, distance = "euclidean", min.nc = 2, max.nc = 10, 
              method = "kmeans", index="all")

# MANHATTAN
set.seed(8)
nb <- NbClust(dfNormZ_no_outliers, distance = "manhattan", min.nc = 2, max.nc = 10, method =     
                "kmeans",     index="all")

# MAXIMUM
set.seed(6)
nb <- NbClust(dfNormZ_no_outliers, distance = "maximum", min.nc = 2, max.nc = 10, method =     
                "kmeans",     index="all")


# SILHOUTTE
set.seed(12)
silh_nb <- fviz_nbclust(dfNormZ_no_outliers, kmeans, method = "silhouette")
print(silh_nb)

# GAP STATS
set.seed(14)
gap_nb <- fviz_nbclust(dfNormZ_no_outliers, kmeans, method = "gap_stat")
print(gap_nb)

# ELBOW 
k = 2:10
set.seed(42)
WSS = sapply(k, function(k) {kmeans(dfNormZ_no_outliers, centers=k)$tot.withinss})
plot(k, WSS, type="b", xlab= "Number of k", ylab="Within sum of squares")


# ELBOW FOR OPTIMUM CLUSTERS
wss_nb <- fviz_nbclust(dfNormZ_no_outliers, kmeans, method = "wss")
print(wss_nb)


### K MEANS CLUSTERING ###
# ASSINGING K VALUE
k_value = 2

# PASSING AND GETTING THE K MEANS
km <- kmeans(dfNormZ_no_outliers, centers= k_value, nstart= 20)
km

# CALCULATING CENTROIDS
centroids <- km$centers
centroids
# PLOTTING 
# fviz_cluster(km,data=dfNormZ_no_outliers)

# PLOTTING 
library(fpc)
plotcluster(dfNormZ_no_outliers, km$cluster)

# CALCULATING WSS AND BSS
wine_wss = km$tot.withinss
wine_wss
wine_bss = km$betweenss
wine_bss


# CALCULATING TSS -> SUM OF BOTH WSS AND BSS
wine_tss= wine_wss+wine_bss
wine_tss

# RATIO BETWEEN WSS AND TSS
ratio_wss_bss <- wine_wss / wine_tss
ratio_wss_bss

# RATIO BETWEEN BSS AND TSS
ratio_wss_tss <- wine_bss / wine_tss
ratio_wss_tss

# SILHOUTTE PLOT
silh <- silhouette(km$cluster, dist(dfNormZ_no_outliers))
fviz_silhouette(silh)

# AVERGAE WIDTH EXTRACTING AND PRINTING
avg_silh_width <- mean(silh[, "sil_width"])
print(paste("Average silhoette width score is ", avg_silh_width))




################ SUB TAST 2 - PCA #################
# CALCULATING EIGEN VALUES AND EIGEN VECTORS
pca <- dfNormZ_no_outliers
wine.cov <- cov(pca)
# VALUES
wine.eigen <- eigen(wine.cov)
str(wine.cov)

# VECTORS
vectors <- wine.eigen$vectors
phi

# CALCULATING SCORES FOR ALL PC -> PRINCIPAL COMPONENTS
PC <- as.matrix(dfNormZ_no_outliers) %*% vectors
PC

# CALCULATING SCORE PER PC
eigenVal <- wine.eigen$values
cumulative_scores <- cumsum(eigenVal) / sum(eigenVal)
cumulative_scores

# CALCULATING SELECTED CUMULATIVE SCORE - ANYTHING BELOW 0.85 THE THRESHOLD GIVEN
select_cumula_scores <- which(cumulative_scores > 0.85)[1]
select_cumula_scores

# CREATE A DATASET WITH THE PCA PROCESSED DATA
transformed <- as.data.frame(PC[, 1:select_cumula_scores])
head(transformed)
head(dfNormZ_no_outliers)



## PERFORM NB CLUST ## 
# EUCLIDEAN
set.seed(10)
nb <- NbClust(transformed, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans", index="all")

# MANHATTAN
set.seed(8)
nb <- NbClust(transformed, distance = "manhattan", min.nc = 2, max.nc = 10, method = "kmeans", index="all")

# MAXIMUM
set.seed(6)
nb <- NbClust(transformed, distance = "maximum", min.nc = 2, max.nc = 10, method = "kmeans", index="all")

# ELBOW METHOD
k = 2:10
set.seed(42)
WSS = sapply(k, function(k) {kmeans(transformed, centers=k)$tot.withinss})
plot(k, WSS, type="b", xlab= "Number of k", ylab="Within sum of squares")

# ELBOW FOR OPTIMAL CLUSTER 
wss_nb <- fviz_nbclust(transformed, kmeans, method = "wss")
print(wss_nb)

# SILHOUETTE
set.seed(12)
silh_nb <- fviz_nbclust(transformed, kmeans, method = "silhouette")
print(silh_nb)

# GAP STATS
set.seed(14)
gap_nb <- fviz_nbclust(transformed, kmeans, method = "gap_stat")
print(gap_nb)

### K MEANS CLUSTERING ###
# K VALUE
k_value = 2

# K MEANS
pca_km <- kmeans(transformed, centers= k_value, nstart= 20)
pca_km

# CALCULATE CENTROIDS
centroid_pca <- pca_km$centers

# PLOTTING
# fviz_cluster(pca_km,data=transformed)
plotcluster(transformed, pca_km$cluster)


# CALCULATE WSS AND BSS
wine_pca_wss = pca_km$tot.withinss
wine_pca_wss
wine_pca_bss = pca_km$betweenss
wine_pca_bss

 
# CALCULATING TSS -> SUM OF BOTH WSS AND BSS
wine_pca_tss= wine_pca_wss+wine_pca_bss
wine_pca_tss

# RATIO BETWEEN WSS AND TSS
ratio_wss_tss <- wine_pca_wss / wine_pca_tss
ratio_wss_tss

# RATIO BETWEEN BSS AND TSS
ratio_bss_tss <- wine_pca_bss / wine_pca_tss
ratio_bss_tss


# SILHOUTTE PLOT
silh <- silhouette(pca_km$cluster, dist(transformed))
fviz_silhouette(silh)


# AVERGAE WIDTH EXTRACTING AND PRINTING
avg_silh_width <- mean(silh[, "sil_width"])
print(paste("Average silhoette width score is ", avg_silh_width))
 
# CONVERTING DATASET INTO A FORMAT FOR CALINSKI HARABASZ
transformed <- dist(transformed)
str(transformed)

# CALINSKI HARABASZ INDEX CALCULATION
library(fpc)

calin_Harab_index <- cluster.stats(transformed, pca_km$cluster)$ch
print(calin_Harab_index)

